const output = validate(agentResult); fs.writeFile('/tmp/out', output);
