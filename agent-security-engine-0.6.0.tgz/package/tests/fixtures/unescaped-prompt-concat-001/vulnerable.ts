const prompt = 'system: ' + userInput;
