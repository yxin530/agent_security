client.chat({ messages: [{ role: 'user', content: '<tool-data>' + escape(toolResult) }] });
