fineTune(verifyChecksum(signedDataset));
