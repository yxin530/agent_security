<?php $q = "SELECT * FROM users WHERE id = " . $userId;
