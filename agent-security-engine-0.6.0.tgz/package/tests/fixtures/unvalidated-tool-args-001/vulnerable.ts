exec(toolCall.arguments.command);
