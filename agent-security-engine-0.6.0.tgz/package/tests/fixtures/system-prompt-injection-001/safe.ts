messages: [{ role: 'user', content: userInput }]
