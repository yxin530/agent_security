print('user@example.com')
