package main
var q = fmt.Sprintf("SELECT * FROM users WHERE id = %s", userID)
