<?php return ['allowed_origins' => ['https://example.com'], 'supports_credentials' => true];
