context += toolResult; client.messages.create({ context });
