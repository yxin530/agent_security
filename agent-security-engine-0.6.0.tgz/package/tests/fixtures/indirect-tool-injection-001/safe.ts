context += '[TOOL_RESULT]' + escape(toolResult);
