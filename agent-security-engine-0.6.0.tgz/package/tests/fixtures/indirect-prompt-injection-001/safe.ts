const prompt = 'Summarize <document>' + sanitize(response.data) + '</document>';
