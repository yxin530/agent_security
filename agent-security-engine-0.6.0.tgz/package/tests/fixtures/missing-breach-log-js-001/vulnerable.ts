app.get("/export", (req, res) => { res.json(userData); });
