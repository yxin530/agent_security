<?php Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
