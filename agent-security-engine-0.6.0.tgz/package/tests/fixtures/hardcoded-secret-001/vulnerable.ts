const apiKey = "FAKEsk_live_ABCDEF1234567890fake";
export { apiKey };
